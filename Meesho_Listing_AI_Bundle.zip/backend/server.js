import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "12mb" }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const prompt = `
You are a product-listing assistant for an Indian fashion seller.
Analyze the supplied product photo and return ONLY valid JSON.
Required keys:
title: string,
keywords: array of 8-15 short search phrases,
category: string,
colour: string,
fabric: string,
pattern: string,
description: string.

Rules:
- Describe only what can reasonably be inferred from the image.
- Do not invent fabric, brand, measurements, certifications, discounts, or features that are not visible/provided.
- If fabric cannot be determined confidently, use "Not clearly visible".
- Keep title concise and marketplace-friendly.
- Description should be factual and useful.
- Keywords should be relevant, not repetitive.
`;

app.post("/analyze-listing", async (req, res) => {
  try {
    const { image_data_url } = req.body;
    if (!image_data_url || !image_data_url.startsWith("data:image/")) {
      return res.status(400).json({ error: "image_data_url is required" });
    }

    const response = await client.responses.create({
      model: "gpt-5",
      input: [{
        role: "user",
        content: [
          { type: "input_text", text: prompt },
          { type: "input_image", image_url: image_data_url, detail: "high" }
        ]
      }]
    });

    let text = response.output_text.trim();
    text = text.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
    const result = JSON.parse(text);
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI analysis failed" });
  }
});

app.get("/health", (_, res) => res.json({ ok: true }));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`AI backend running on ${port}`));
