package com.example.meesholistingai

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ProductDraft(
    val imageUri: String = "",
    val title: String = "",
    val category: String = "Saree",
    val colour: String = "",
    val fabric: String = "",
    val pattern: String = "",
    val keywords: String = "",
    val description: String = "",
    val price: String = "",
    val quantity: String = ""
)

private const val AI_ENDPOINT = "https://YOUR-SERVER-DOMAIN.com/analyze-listing"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeeshoListingAI() }
    }
}

@Composable
fun MeeshoListingAI() {
    var screen by remember { mutableStateOf("home") }
    var draft by remember { mutableStateOf(ProductDraft()) }

    MaterialTheme {
        Scaffold(bottomBar = {
            NavigationBar {
                listOf("Home", "Products", "Add", "Drafts").forEach { item ->
                    NavigationBarItem(
                        selected = screen == item.lowercase(),
                        onClick = { screen = item.lowercase() },
                        icon = {},
                        label = { Text(item) }
                    )
                }
            }
        }) { pad ->
            when (screen) {
                "home" -> Home(pad) { screen = "add" }
                "add" -> AddProduct(pad, draft, { draft = it }) { screen = "preview" }
                "preview" -> Preview(pad, draft)
                else -> Placeholder(pad, screen)
            }
        }
    }
}

@Composable
fun Home(pad: PaddingValues, onAdd: () -> Unit) {
    Column(Modifier.padding(pad).padding(20.dp)) {
        Text("Meesho Listing AI", style = MaterialTheme.typography.headlineMedium)
        Text("Photo → AI listing in one step")
        Spacer(Modifier.height(24.dp))
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) {
            Text("✨ New Listing")
        }
        Spacer(Modifier.height(18.dp))
        Text("AI will fill title, keywords, category, colour, fabric and description from the product photo.")
        Spacer(Modifier.height(12.dp))
        Text("No ARCore or Google Play Services dependency.")
    }
}

@Composable
fun AddProduct(
    pad: PaddingValues,
    draft: ProductDraft,
    onDraft: (ProductDraft) -> Unit,
    onPreview: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var analyzing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        onDraft(draft.copy(imageUri = uri.toString()))
        analyzing = true
        message = "AI is analyzing the photo…"
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                analyzeImage(AppContextHolder.context, uri)
            }
            analyzing = false
            result.fold(
                onSuccess = {
                    onDraft(draft.copy(
                        imageUri = uri.toString(),
                        title = it.optString("title"),
                        category = it.optString("category", "Saree"),
                        colour = it.optString("colour"),
                        fabric = it.optString("fabric"),
                        pattern = it.optString("pattern"),
                        keywords = it.optJSONArray("keywords")?.join(", ") ?: "",
                        description = it.optString("description")
                    ))
                    message = "✓ AI filled the listing. Please review before publishing."
                },
                onFailure = { message = "AI analysis failed: ${it.message}. Check your server URL/API setup." }
            )
        }
    }

    LazyColumn(
        Modifier.padding(pad).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Add Product", style = MaterialTheme.typography.headlineMedium) }
        item {
            OutlinedButton(
                onClick = { picker.launch(arrayOf("image/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (draft.imageUri.isBlank()) "📷 Add Product Photo" else "✓ Photo Added") }
        }
        if (analyzing) item {
            LinearProgressIndicator(Modifier.fillMaxWidth())
        }
        if (message.isNotBlank()) item { Text(message) }

        item { Field("Title", draft.title) { onDraft(draft.copy(title = it)) } }
        item { Field("Category", draft.category) { onDraft(draft.copy(category = it)) } }
        item { Field("Colour", draft.colour) { onDraft(draft.copy(colour = it)) } }
        item { Field("Fabric", draft.fabric) { onDraft(draft.copy(fabric = it)) } }
        item { Field("Pattern", draft.pattern) { onDraft(draft.copy(pattern = it)) } }
        item { Field("Keywords", draft.keywords) { onDraft(draft.copy(keywords = it)) } }
        item { Field("Description", draft.description) { onDraft(draft.copy(description = it)) } }
        item { Field("Price ₹", draft.price) { onDraft(draft.copy(price = it)) } }
        item { Field("Quantity", draft.quantity) { onDraft(draft.copy(quantity = it)) } }
        item {
            Button(onClick = onPreview, modifier = Modifier.fillMaxWidth()) {
                Text("Preview Listing")
            }
        }
    }
}

@Composable
fun Field(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth())
}

@Composable
fun Preview(pad: PaddingValues, draft: ProductDraft) {
    Column(Modifier.padding(pad).padding(20.dp)) {
        Text("Listing Preview", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text(draft.title.ifBlank { "Product title" }, style = MaterialTheme.typography.titleLarge)
                Text("Category: ${draft.category}")
                Text("Colour: ${draft.colour.ifBlank { "Not set" }}")
                Text("Fabric: ${draft.fabric.ifBlank { "Not set" }}")
                Text("Pattern: ${draft.pattern.ifBlank { "Not set" }}")
                Text("Keywords: ${draft.keywords.ifBlank { "Not set" }}")
                Text("Price: ₹${draft.price.ifBlank { "0" }}")
                Spacer(Modifier.height(10.dp))
                Text(draft.description.ifBlank { "Description will appear here." })
            }
        }
        Spacer(Modifier.height(18.dp))
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) {
            Text("🚀 Publish to Meesho")
        }
        Text("Publishing will be enabled only through an authorized official integration.")
    }
}

@Composable
fun Placeholder(pad: PaddingValues, name: String) {
    Box(Modifier.padding(pad).padding(20.dp)) {
        Text("${name.replaceFirstChar { it.uppercase() }} screen — coming next")
    }
}

private fun analyzeImage(context: Context, uri: Uri): Result<JSONObject> = runCatching {
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        ?: error("Could not read image")
    val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
    val dataUrl = "data:$mime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)

    val payload = JSONObject().put("image_data_url", dataUrl)
    val conn = (URL(AI_ENDPOINT).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 30_000
        readTimeout = 60_000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
    }
    conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
    val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
    val response = stream.bufferedReader().use { it.readText() }
    if (conn.responseCode !in 200..299) error(response)
    JSONObject(response)
}

object AppContextHolder {
    lateinit var context: Context
}
