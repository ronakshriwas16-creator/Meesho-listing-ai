# Meesho Listing AI — Zero-AR Android Project

ZERO augmented-reality functionality is used.

No AR library or Google Play Services dependency is included.
Product photos are selected with Android's standard document picker.

## AI auto-fill
Photo → HTTPS backend → vision AI → structured JSON → automatic:
- Title
- Keywords
- Category
- Colour
- Fabric
- Pattern
- Description

## Build
Open this folder in Android Studio and choose:
Build > Build APK(s)

Debug APK output:
app/build/outputs/apk/debug/app-debug.apk

Keep the AI API key on the backend, never inside the Android app.

Meesho publishing remains a placeholder until an authorized official seller/API integration is configured.
